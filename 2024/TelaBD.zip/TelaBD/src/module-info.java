/**
 * 
 */
/**
 * 
 */
module TelaBD {
	requires java.desktop;
	requires java.sql;
}