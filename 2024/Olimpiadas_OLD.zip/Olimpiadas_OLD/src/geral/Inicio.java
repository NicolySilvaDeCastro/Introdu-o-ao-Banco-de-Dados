package geral;

import java.sql.SQLException;

public class Inicio {
	public static void main(String[] args) throws SQLException {
		Tela tl = new Tela();
	}
}
