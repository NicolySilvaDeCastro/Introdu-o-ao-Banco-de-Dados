package geral;

import java.awt.Color;
import java.awt.Font;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTable;

public class Tela extends JFrame {
	public JComboBox cbPais = new JComboBox();
	public JComboBox cbModalidade = new JComboBox();
	public JTable tableMedalha;
	
	public Tela() throws SQLException {
		super("Tela de Cadastro de Medalhas");
		setSize(485, 680);
		setLayout(null);
		getContentPane().setBackground(new Color(240, 230, 140));
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		JLabel jLtitulo = new JLabel("Olimpíadas 2024 - Quadro de Medalhas");
		jLtitulo.setBounds(5, 0, 850, 60);
		jLtitulo.setFont(new Font ("Arial", Font.BOLD, 25));
		add(jLtitulo);
		JLabel jlNome = new JLabel("País:");
		jlNome.setBounds(10, 70, 850, 60);
		add(jlNome);
		BDUtil bdPais = new BDUtil();
		bdPais.executaBDSelect("Select * from pais","nome");
		cbPais.setModel(new DefaultComboBoxModel(new Vector(bdPais.getLista())));
		cbPais.setBounds(70, 90, 200, 20);
		add(cbPais);
		setVisible(true);
	}
	
}
