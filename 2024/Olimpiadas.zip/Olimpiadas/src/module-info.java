/**
 * 
 */
/**
 * 
 */
module Olimpiadas {
	requires java.sql;
	requires java.desktop;
}